class alumnos:
    def __init__(self, nombre, edad, curso, notas):
        self.nombre = nombre
        self.edad = edad
        self.curso = curso
        self.notas = notas

    def comprobar(self):
        if self.notas >= 60:
            print(f"El alumno {self.nombre} de edad {self.edad} del curso {self.curso} ha aprobado con {self.notas}")
        else:
            print(f"El alumno {self.nombre} de edad {self.edad} del curso {self.curso} no ha aprobado con {self.notas}")

alumno1 = alumnos("Juan", 15, "1º", 70)
alumno2 = alumnos("Pedro", 16, "2º", 50)
alumno1.comprobar()
alumno2.comprobar()